-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2020 at 11:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `konstratani`
--
CREATE DATABASE IF NOT EXISTS `konstratani` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `konstratani`;

-- --------------------------------------------------------

--
-- Table structure for table `desa`
--

CREATE TABLE `desa` (
  `id_desa` int(11) NOT NULL,
  `nama_desa` varchar(20) NOT NULL,
  `kecamatan` varchar(20) NOT NULL,
  `kabupaten` varchar(20) NOT NULL,
  `luas_baku` decimal(8,2) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `desa`
--

INSERT INTO `desa` (`id_desa`, `nama_desa`, `kecamatan`, `kabupaten`, `luas_baku`, `updated_at`, `created_at`) VALUES
(1, 'Wukirharjo', 'Prambanan', 'Sleman', '77.00', '2020-02-27 04:49:04', '2020-02-27 04:49:04'),
(2, 'Madurejo', 'Prambanan', 'Sleman', '355.00', '2020-02-27 04:49:04', '2020-02-27 04:49:04'),
(3, 'Sumberharjo', 'Prambanan', 'Sleman', '372.00', '2020-02-27 07:23:57', '2020-02-27 07:23:57'),
(4, 'Bokoharjo', 'Prambanan', 'Sleman', '147.00', '2020-03-04 17:06:55', '2020-03-04 17:06:55'),
(5, 'Sambirejo', 'Prambanan', 'Sleman', '119.00', '2020-03-05 16:43:28', '2020-03-05 16:43:28'),
(6, 'Gayamharjo', 'Prambanan', 'Sleman', '102.00', '2020-03-05 16:43:28', '2020-03-05 16:43:28');

-- --------------------------------------------------------

--
-- Table structure for table `dusun`
--

CREATE TABLE `dusun` (
  `nama_dusun` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_desa` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dusun`
--

INSERT INTO `dusun` (`nama_dusun`, `created_at`, `updated_at`, `id_desa`, `id`) VALUES
('Beloran', '2020-03-18 07:32:35', '2020-03-04 05:21:52', 2, 2),
('Bendungan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Berjo', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Bleber Kidul', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Candi Rejo', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Candisari', '2020-03-18 07:32:35', '2020-03-16 17:08:43', 1, 1),
('Candisingo', '2020-03-18 07:32:35', '2020-03-04 05:22:29', 2, 2),
('Cepik', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Dadap', '2020-03-19 15:06:50', '2020-03-19 15:06:50', 6, 6),
('Daleman', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Dawangsari', '2020-03-19 15:03:33', '2020-03-19 15:03:33', 5, 5),
('Dawung', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Dayakan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Dinginan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Dukuh', '2020-03-18 07:32:35', '2020-03-04 05:23:11', 2, 2),
('Gamparan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Gangsiran', '2020-03-18 07:32:35', '2020-03-04 05:23:11', 2, 2),
('Gatak', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Gayam', '2020-03-19 15:05:23', '2020-03-19 15:05:23', 6, 6),
('Gedang Atas', '2020-03-19 15:04:04', '2020-03-19 15:04:04', 5, 5),
('Gedang Bawah', '2020-03-19 15:04:04', '2020-03-19 15:04:04', 5, 5),
('Gunugnsari', '2020-03-19 15:03:33', '2020-03-19 15:03:33', 5, 5),
('Gunung Cilik', '2020-03-19 15:04:29', '2020-03-19 15:04:29', 5, 5),
('Gunung gebang', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Jali', '2020-03-19 15:07:37', '2020-03-19 15:07:37', 6, 6),
('Jaligampang', '2020-03-19 15:07:37', '2020-03-19 15:07:37', 6, 6),
('Jamuran', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Jatisari', '2020-03-19 15:06:23', '2020-03-19 15:06:23', 6, 6),
('Jirak', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Jobohan', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Jontro', '2020-03-19 15:07:14', '2020-03-19 15:07:14', 6, 6),
('Jurugan', '2020-03-18 17:43:13', '2020-03-18 17:43:13', 3, 3),
('Kalinongko Kidul', '2020-03-19 15:06:50', '2020-03-19 15:06:50', 6, 6),
('Kalinongko Lor', '2020-03-19 15:07:14', '2020-03-19 15:07:14', 6, 6),
('Kebon Dalem', '2020-03-18 07:32:35', '2020-03-04 05:23:57', 2, 2),
('Kembang', '2020-03-18 07:32:35', '2020-03-04 05:23:57', 2, 2),
('Kenaran', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Ketandan', '2020-03-18 07:32:35', '2020-03-04 05:25:50', 2, 2),
('Kikis', '2020-03-19 15:02:54', '2020-03-19 15:02:54', 5, 5),
('Klero', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Klumprit 1', '2020-03-18 07:32:35', '2020-03-16 17:08:43', 1, 1),
('Klumprit 2', '2020-03-18 07:32:35', '2020-03-16 17:08:43', 1, 1),
('Krapyak', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Kuncen', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Lemahbang', '2020-03-19 15:05:46', '2020-03-19 15:05:46', 6, 6),
('Losari 1', '2020-03-18 07:32:35', '2020-03-16 17:08:43', 1, 1),
('Losari 2', '2020-03-18 07:32:35', '2020-03-16 17:08:43', 1, 1),
('Majasem', '2020-03-18 07:32:35', '2020-03-04 05:25:50', 2, 2),
('Majesam', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Marangan', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Mlakan', '2020-03-19 15:04:29', '2020-03-19 15:04:29', 5, 5),
('Morobangun', '2020-03-18 07:32:35', '2020-03-07 06:03:14', 2, 2),
('Mutihan', '2020-03-18 07:32:35', '2020-03-04 05:27:27', 2, 2),
('Nawung', '2020-03-19 15:05:46', '2020-03-19 15:05:46', 6, 6),
('Ngeburan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Nglengkong', '2020-03-19 15:02:54', '2020-03-19 15:02:54', 5, 5),
('Nglepen', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Nogosari', '2020-03-18 07:32:36', '2020-03-04 05:27:27', 2, 2),
('Palem Sari', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Parangan', '2020-03-19 15:05:23', '2020-03-19 15:05:23', 6, 6),
('Patran', '2020-03-18 07:32:36', '2020-03-07 06:03:14', 2, 2),
('Pereng', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Polongan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Potrojayan', '2020-03-18 07:32:36', '2020-03-04 05:27:59', 2, 2),
('Pulorejo', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Randujoko', '2020-03-18 17:58:50', '2020-03-18 16:57:48', 3, 3),
('Ringin Sari', '2020-03-19 11:36:38', '2020-03-19 11:36:38', 4, 4),
('Sawo', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Sembir', '2020-03-18 07:32:36', '2020-03-04 05:27:59', 2, 2),
('Sengir', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Serut', '2020-03-18 07:32:36', '2020-03-04 05:28:47', 2, 2),
('Slarongan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Sonayan', '2020-03-18 07:32:36', '2020-03-07 06:03:28', 2, 2),
('Sorogedug Kidul', '2020-03-18 07:32:36', '2020-03-04 05:28:47', 2, 2),
('Sorogedug Lor', '2020-03-18 07:32:36', '2020-03-04 05:29:24', 2, 2),
('Sumberwatu', '2020-03-19 15:04:49', '2020-03-19 15:04:49', 5, 5),
('Tinjon', '2020-03-18 07:32:36', '2020-03-04 05:29:24', 2, 2),
('Tungan', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Umbul Sari A', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Umbul Sari B', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Umbul Sari BM', '2020-03-18 16:56:59', '2020-03-18 16:56:59', 3, 3),
('Watu Gudeg', '2020-03-19 15:06:23', '2020-03-19 15:06:23', 6, 6),
('Watukangsi', '2020-03-18 07:32:36', '2020-03-16 17:08:43', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `frekuensi_tanam`
--

CREATE TABLE `frekuensi_tanam` (
  `id_frekuensi` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `teririgasi_satu` decimal(8,2) NOT NULL,
  `teririgasi_dua` decimal(8,2) NOT NULL,
  `teririgasi_tiga` decimal(8,2) NOT NULL,
  `tidak_ditanami` decimal(8,2) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `frekuensi_tanam`
--

INSERT INTO `frekuensi_tanam` (`id_frekuensi`, `tanggal_input`, `teririgasi_satu`, `teririgasi_dua`, `teririgasi_tiga`, `tidak_ditanami`, `updated_at`, `created_at`) VALUES
(3, '2020-02-17', '2000.54', '2000.54', '2000.54', '2000.54', '2020-02-17 08:53:38', '2020-02-17 08:52:48');

-- --------------------------------------------------------

--
-- Table structure for table `hama`
--

CREATE TABLE `hama` (
  `id_hama` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `tikus` decimal(8,2) NOT NULL,
  `wereng_coklat` decimal(8,2) NOT NULL,
  `penggerek` decimal(8,2) NOT NULL,
  `tungro` decimal(8,2) NOT NULL,
  `blb` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hama`
--

INSERT INTO `hama` (`id_hama`, `tanggal_input`, `tikus`, `wereng_coklat`, `penggerek`, `tungro`, `blb`, `created_at`, `updated_at`) VALUES
(4, '2020-02-14', '3000.54', '3000.54', '3000.54', '3000.54', '3000.54', '2020-02-14 16:12:41', '2020-02-14 16:12:57');

-- --------------------------------------------------------

--
-- Table structure for table `kecamatan`
--

CREATE TABLE `kecamatan` (
  `id_kecamatan` int(11) NOT NULL,
  `nama_kecamatan` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kotani`
--

CREATE TABLE `kotani` (
  `id_kotani` int(11) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `luas_baku` decimal(8,2) NOT NULL,
  `nama_ketua` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `no_hp` varchar(15) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kotani`
--

INSERT INTO `kotani` (`id_kotani`, `nama_kotani`, `tanggal_input`, `nama_dusun`, `luas_baku`, `nama_ketua`, `created_at`, `updated_at`, `no_hp`, `id`) VALUES
(1, 'Beloran', '2020-03-05', 'Beloran', '12.00', 'Jabidi', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '085228400809', 2),
(2, 'Dadi Subur', '2020-03-05', 'Serut', '23.00', 'Suratmin', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '085878500078', 2),
(3, 'Eko Mulyo', '2020-03-05', 'Mutihan', '29.00', 'Mujiono', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '', 2),
(4, 'Kembang', '2020-03-05', 'Kembang', '17.00', 'Sujarwoko', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '089648774202', 2),
(5, 'Maju', '2020-03-05', 'Kebon Dalem', '11.00', 'Suyanto', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '081578411279', 2),
(6, 'Manunggal Patran', '2020-03-05', 'Patran', '24.00', 'Suharyanta', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '081227947415', 2),
(8, 'Morobangun', '2020-03-05', 'Morobangun', '20.00', 'Parwata', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '081329193584', 2),
(9, 'Naga Sakti', '2020-03-05', 'Nogosari', '22.00', 'Muh Sukimin', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '', 2),
(10, 'Ngudi Makmur', '2020-03-05', 'Gangsiran', '30.00', 'Mulyono', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '085329311496', 2),
(11, 'Ngudi Mekar', '2020-03-05', 'Sorogedug Lor', '17.00', 'Hartono', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '085876221199', 2),
(12, 'Pesona', '2020-03-05', 'Sonayan', '16.00', 'Soepodo', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '', 2),
(13, 'Ringin Putih', '2020-03-05', 'Sembir', '18.00', 'Jumadi', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '08972100550', 2),
(14, 'Sedya Mulyo', '2020-03-05', 'Ketandan', '15.00', 'Darto Sumarti', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '08978092368', 2),
(15, 'Sedya Rukun', '2020-03-05', 'Candisingo', '23.00', 'Sudiro', '2020-03-24 17:01:04', '2020-03-07 03:15:20', '', 2),
(16, 'Sido Rukun', '2020-03-05', 'Tinjon', '18.00', 'Dwiyono', '2020-03-24 17:01:05', '2020-03-07 03:15:20', '', 2),
(17, 'Sorogedug Kidul', '2020-03-05', 'Sorogedug Kidul', '15.00', 'Sujadi', '2020-03-24 17:01:05', '2020-03-07 03:15:20', '', 2),
(18, 'Tanem Tuwuh', '2020-03-05', 'Potrojayan', '10.00', 'Agus Susanto', '2020-03-24 17:01:05', '2020-03-07 03:15:20', '081328124995', 2),
(19, 'Tani Rejo', '2020-03-05', 'Majasem', '20.00', 'Lipur Dwi A', '2020-03-24 17:01:05', '2020-03-07 03:15:20', '08979709640', 2),
(20, 'Tunas Jaya', '2020-03-05', 'Kebon Dalem', '15.00', 'Maryanto', '2020-03-24 17:01:05', '2020-03-07 03:15:20', '085100676558', 2),
(21, 'Tani Maju', '2020-03-17', 'Klumprit 2', '10.00', 'Suyanto', '2020-03-24 17:01:05', '2020-03-17 00:02:11', '081327579997', 1),
(22, 'Margi Waluyo', '2020-03-17', 'Watukangsi', '7.00', 'Rubiman', '2020-03-24 17:01:05', '2020-03-17 00:13:27', '081217234722', 1),
(23, 'Sido Rahayu', '2020-03-17', 'Watukangsi', '5.00', 'Sukidi', '2020-03-24 17:01:05', '2020-03-17 00:20:11', '085725858791', 1),
(24, 'Ngudi Makmur', '2020-03-17', 'Losari 1', '6.00', 'Masiran', '2020-03-17 07:22:40', '2020-03-17 00:21:57', '08156882575', 2),
(25, 'Margo Dadi', '2020-03-17', 'Losari 1', '7.00', 'Supriyanto', '2020-03-17 07:42:10', '2020-03-17 00:24:30', '085727757526', 2),
(26, 'Rukun Santoso', '2020-03-17', 'Losari 2', '7.00', 'Purwiyanto', '2020-03-17 00:43:15', '2020-03-17 00:43:15', '085228256501', 2),
(27, 'Ngudi Rejeki', '2020-03-17', 'Losari 2', '7.00', 'Musimin', '2020-03-24 17:02:03', '2020-03-17 00:47:32', '082324318323', 1),
(28, 'Madyo Rahayu', '2020-03-17', 'Candisari', '9.00', 'Dalijo', '2020-03-24 17:02:03', '2020-03-17 00:57:34', '082133265422', 1),
(29, 'Murih Raharjo', '2020-03-17', 'Candisari', '5.00', 'Suripto', '2020-03-24 17:02:03', '2020-03-17 00:57:59', '0', 1),
(30, 'Murih Mulyo', '2020-03-17', 'Klumprit 1', '8.00', 'Simpang', '2020-03-24 17:02:03', '2020-03-17 00:58:31', '085600921179', 1),
(31, 'Ngudi Rukun', '2020-03-17', 'Klumprit 1', '6.00', 'Sukirman', '2020-03-24 17:02:03', '2020-03-17 00:59:04', '081215182300', 1),
(32, 'Sido Dadi', '2020-03-18', 'Dinginan', '19.00', 'Sholeh', '2020-03-18 10:23:43', '2020-03-18 10:23:43', '085647490570', 3),
(33, 'Manunggal', '2020-03-18', 'Polongan', '18.00', 'Sholeh', '2020-03-18 10:29:34', '2020-03-18 10:29:34', '085647490570', 3),
(34, 'Amanah', '2020-03-18', 'Krapyak', '15.00', 'Sholeh', '2020-03-18 10:31:40', '2020-03-18 10:31:40', '085647490570', 3),
(35, 'Subur Makmur', '2020-03-18', 'Gunung gebang', '26.00', 'Sholeh', '2020-03-18 10:34:36', '2020-03-18 10:34:36', '085647490570', 3),
(36, 'Rukun Makmur', '2020-03-18', 'Slarongan', '15.00', 'Sholeh', '2020-03-18 10:35:28', '2020-03-18 10:35:28', '085647490570', 3),
(37, 'Karya Muda', '2020-03-18', 'Bleber Kidul', '12.00', 'Sholeh', '2020-03-18 10:36:11', '2020-03-18 10:36:11', '085647490570', 3),
(38, 'Sumber Mulyo', '2020-03-18', 'Berjo', '18.00', 'Sholeh', '2020-03-18 10:40:19', '2020-03-18 10:40:19', '085647490570', 3),
(39, 'Ngudi Rejeki', '2020-03-18', 'Jurugan', '18.00', 'Sholeh', '2020-03-18 10:44:05', '2020-03-18 10:44:05', '085647490570', 3),
(40, 'Triboga', '2020-03-18', 'Daleman', '22.00', 'Sholeh', '2020-03-18 10:44:50', '2020-03-18 10:44:50', '085647490570', 3),
(41, 'Sido Makmur', '2020-03-18', 'Ngeburan', '18.00', 'Sholeh', '2020-03-18 10:46:55', '2020-03-18 10:46:55', '085647490570', 3),
(42, 'Ngudi Rejeki', '2020-03-18', 'Klero', '17.00', 'Sholeh', '2020-03-18 10:47:31', '2020-03-18 10:47:31', '085647490570', 3),
(43, 'Margu Mulyo', '2020-03-18', 'Bendungan', '18.00', 'Sholeh', '2020-03-18 10:48:25', '2020-03-18 10:48:25', '085647490570', 3),
(44, 'Sido Makmur', '2020-03-18', 'Kenaran', '18.00', 'Sholeh', '2020-03-18 10:48:57', '2020-03-18 10:48:57', '085647490570', 3),
(45, 'Ngudi Rejeki', '2020-03-18', 'Sawo', '17.00', 'Sholeh', '2020-03-18 10:49:40', '2020-03-18 10:49:40', '085647490570', 3),
(46, 'Mekar Sari', '2020-03-18', 'Umbul Sari BM', '10.00', 'Sholeh', '2020-03-18 10:50:34', '2020-03-18 10:50:34', '085647490570', 3),
(47, 'Rukun Makmur', '2020-03-18', 'Umbul Sari B', '12.00', 'Sholeh', '2020-03-18 10:51:39', '2020-03-18 10:51:39', '085647490570', 3),
(48, 'Umbul Makmur', '2020-03-18', 'Umbul Sari A', '10.00', 'Sholeh', '2020-03-18 10:52:16', '2020-03-18 10:52:16', '085647490570', 3),
(49, 'Tani Makmur', '2020-03-18', 'Nglepen', '10.00', 'Sholeh', '2020-03-18 10:53:06', '2020-03-18 10:53:06', '085647490570', 3),
(50, 'Sari Makmur', '2020-03-18', 'Sengir', '18.00', 'Sholeh', '2020-03-18 10:53:39', '2020-03-18 10:53:39', '085647490570', 3),
(51, 'Manunggal', '2020-03-18', 'Kuncen', '13.00', 'Sholeh', '2020-03-18 10:54:25', '2020-03-18 10:54:25', '085647490570', 3),
(52, 'Ngudi Makmur', '2020-03-18', 'Pereng', '10.00', 'Sholeh', '2020-03-18 10:55:08', '2020-03-18 10:55:08', '085647490570', 3),
(53, 'Tani Makmur', '2020-03-18', 'Gamparan', '18.00', 'Sholeh', '2020-03-18 10:55:44', '2020-03-18 10:55:44', '085647490570', 3),
(54, 'Margo Makmur', '2020-03-18', 'Dayakan', '10.00', 'Sholeh', '2020-03-18 10:56:39', '2020-03-18 10:56:39', '085647490570', 3),
(55, 'Argo Makmur', '2020-03-18', 'Randujoko', '10.00', 'Sholeh', '2020-03-18 18:00:44', '2020-03-18 10:58:15', ' 085647490570', 3),
(56, 'Argo Makmur', '2020-03-19', 'Kikis', '8.00', 'Amad Tumiran', '2020-03-19 12:58:30', '2020-03-19 12:58:30', '081567655731', 5),
(57, 'Budidaya I', '2020-03-19', 'Nglenkong', '7.00', 'Amad Tumiran', '2020-03-19 12:58:30', '2020-03-19 12:58:30', '081567655731', 5),
(58, 'Lestari Rahayu', '2020-03-19', 'Kikis', '13.00', 'Ahmad Tumiran', '2020-03-19 13:00:29', '2020-03-19 13:00:29', '081567655731', 5),
(59, 'Margo Mulyo I', '2020-03-05', 'Dawangsari', '10.00', 'Ahmad Tumiran', '2020-03-19 13:00:29', '2020-03-19 13:00:29', '081567655731', 5),
(60, 'Margo Mulyo II', '2020-03-19', 'Dawangsari', '9.00', 'Ahmad Tumiran', '2020-03-19 13:03:37', '2020-03-19 13:03:37', '081567655731', 5),
(61, 'Ngudi Makmur', '2020-03-19', 'Gunungssari', '3.00', 'Ahmad Tumiran', '2020-03-19 13:03:37', '2020-03-19 13:03:37', '081567655731', 5),
(62, 'Ngudi Makmur II', '2020-03-19', 'Gunungsari', '4.00', 'Ahmad Tumiran', '2020-03-19 13:16:31', '2020-03-19 13:16:31', '081567655731', 5),
(63, 'Ngudi Makmur III', '2020-03-19', 'Gunungsari', '14.00', 'Ahmad Tumiran', '2020-03-19 13:16:31', '2020-03-19 13:16:31', '081567655731', 5),
(64, 'Ngudi Rejeki I', '2020-03-20', 'Gedang Bawah', '10.00', 'Ahmad Tumiran', '2020-03-19 13:22:48', '2020-03-19 13:22:48', '081567655731', 5),
(65, 'Ngudi Rejeki II', '2020-03-19', 'Gedang Atas', '4.00', 'Ahmad Tumiran', '2020-03-19 13:22:48', '2020-03-19 13:22:48', '081567655731', 5),
(66, 'Ngudi Rukun I', '2020-03-19', 'Mlakan', '4.00', 'Ahmad Tuimiran', '2020-03-19 13:25:03', '2020-03-19 13:25:03', '081567655731', 5),
(67, 'Ngudi Rukun II', '2020-03-19', 'Mlakan', '5.00', 'Ahmad Tumiran', '2020-03-19 13:25:03', '2020-03-19 13:25:03', '081567655731', 5),
(68, 'Sido Makmur II', '2020-03-19', 'Gunung Cilik', '9.00', 'Ahmad Tumiran', '2020-03-19 13:28:02', '2020-03-19 13:28:02', '081567655731', 5),
(69, 'Sido Rukun', '2020-03-19', 'Gunung Cilik', '8.00', 'Ahmad Tumiran', '2020-03-19 13:28:02', '2020-03-19 13:28:02', '081567655731', 5),
(70, 'Lebdosari', '2020-03-19', 'Sumberwatu', '9.00', 'Ahmad Tumiran ', '2020-03-19 13:30:00', '2020-03-19 13:30:00', '081567655731', 5),
(71, 'Sedyo Mulyo', '2020-03-19', 'Parangan', '9.00', 'Sugiyo', '2020-03-19 13:34:17', '2020-03-19 13:34:17', '087838649107', 6),
(72, 'Sido Maju', '2020-03-19', 'Gayam', '10.00', 'Sugiyo', '2020-03-19 13:34:17', '2020-03-19 13:34:17', '087838649107', 6),
(73, 'Sido Maju', '2020-03-19', 'Lemahbang', '12.00', 'Sugiyo', '2020-03-19 13:37:23', '2020-03-19 13:37:23', '087838649107', 6),
(74, 'Sedyo Maju', '2020-03-19', 'Nawung', '10.00', 'Sugiyo', '2020-03-19 13:37:23', '2020-03-19 13:37:23', '087838649107', 6),
(75, 'Ngudi Makmur', '2020-03-19', 'Jatisari', '9.00', 'Sugiyo', '2020-03-19 13:41:21', '2020-03-19 13:41:21', '087838649107', 6),
(76, 'Ngudi Subur', '2020-03-19', 'Watugudeg', '8.00', 'Sugiyo', '2020-03-19 13:41:21', '2020-03-19 13:41:21', '087838649107', 6),
(77, 'Sido Makmur', '2020-03-19', 'Dadap', '10.00', 'Sugiyo', '2020-03-19 13:43:18', '2020-03-19 13:43:18', '087838649107', 6),
(78, 'Ngudi Makmur', '2020-03-19', 'Kalinongko Kidul', '9.00', 'Sugiyo', '2020-03-19 13:43:18', '2020-03-19 13:43:18', '087838649107', 6),
(79, 'Sedyo Mulyo', '2020-03-19', 'Kalinongko Lor', '8.00', 'Sugiyo', '2020-03-19 13:52:16', '2020-03-19 13:52:16', '087838649107', 6),
(80, 'Subur', '2020-03-19', 'Jontro', '9.00', 'Sugiyo', '2020-03-19 13:52:16', '2020-03-19 13:52:16', '087838649107', 6),
(81, 'Ngudiwaras', '2020-03-19', 'Jali', '8.00', 'Sugiyo', '2020-03-19 14:59:19', '2020-03-19 14:59:19', '087838649107', 6),
(82, 'Ngudi Makmur', '2020-03-19', 'Jaligampang', '9.00', 'Sugiyo', '2020-03-19 14:59:19', '2020-03-19 14:59:19', '087838649107', 6),
(83, 'Ngudi Mulyo', '2020-03-25', 'Jirak', '12.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(84, 'Jonggrang', '2020-03-23', 'Ringinsari', '10.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(85, 'Pulerejo', '2020-03-24', 'Pulerejo', '8.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(86, 'Sido Makmur', '2020-03-24', 'Jobohan', '12.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(87, 'Tani Makmur', '2020-03-24', 'Jamusan', '25.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(88, 'Ngudi Makmur', '2020-03-24', 'Majesem', '12.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(89, 'Tani Maju', '2020-01-08', 'Cepit', '11.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(90, 'Ngudi Makmur', '2020-01-09', 'Dawung', '11.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(91, 'Dewi sri', '2020-03-24', 'Gatak', '6.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(92, 'Tani Makmur', '2020-03-24', 'Candirejo', '11.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(93, 'Sido Rukun', '2020-03-24', 'Palemsari', '11.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4),
(94, 'Tani Maju', '2020-03-24', 'Marangan', '14.00', 'Setiawan', '2020-03-24 10:20:28', '2020-03-24 10:20:28', '081226934509', 4);

-- --------------------------------------------------------

--
-- Table structure for table `ltt_bmerah`
--

CREATE TABLE `ltt_bmerah` (
  `id_bmerah` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_bmerah` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_bmerah`
--

INSERT INTO `ltt_bmerah` (`id_bmerah`, `tanggal_input`, `ltt_bmerah`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(1, '2020-03-12', '1.90', 'Beloran', 'Beloran', 1, '2020-03-12 08:58:09', '2020-03-12 08:58:09');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_cabai`
--

CREATE TABLE `ltt_cabai` (
  `id_cabai` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_cabai` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_cabai`
--

INSERT INTO `ltt_cabai` (`id_cabai`, `tanggal_input`, `ltt_cabai`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(1, '2020-03-12', '2.20', 'Beloran', 'Beloran', 1, '2020-03-11 20:07:35', '2020-03-11 20:07:35'),
(2, '2020-03-12', '1.80', 'Serut', 'Dadi Subur', 1, '2020-03-12 09:38:26', '2020-03-12 09:38:26');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_jagung`
--

CREATE TABLE `ltt_jagung` (
  `id_jagung` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_jagung` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ltt_jagung`
--

INSERT INTO `ltt_jagung` (`id_jagung`, `tanggal_input`, `ltt_jagung`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(6, '2020-03-09', '2.70', 'Beloran', 'Beloran', 1, '2020-03-10 07:28:24', '2020-03-10 07:28:24'),
(7, '2020-03-17', '3.80', 'Beloran', 'Beloran', 1, '2020-03-10 07:28:40', '2020-03-10 07:28:40');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_kedelai`
--

CREATE TABLE `ltt_kedelai` (
  `id_kedelai` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_kedelai` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_kedelai`
--

INSERT INTO `ltt_kedelai` (`id_kedelai`, `tanggal_input`, `ltt_kedelai`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(2, '2020-03-11', '1.20', 'Beloran', 'Beloran', 1, '2020-03-10 19:50:06', '2020-03-10 19:50:06');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_ktanah`
--

CREATE TABLE `ltt_ktanah` (
  `id_ktanah` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_ktanah` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_ktanah`
--

INSERT INTO `ltt_ktanah` (`id_ktanah`, `tanggal_input`, `ltt_ktanah`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(1, '2020-03-11', '2.50', 'Beloran', 'Beloran', 1, '2020-03-11 07:03:17', '2020-03-11 07:03:17');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_pladang`
--

CREATE TABLE `ltt_pladang` (
  `id_lttpladang` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_pladang` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_pladang`
--

INSERT INTO `ltt_pladang` (`id_lttpladang`, `tanggal_input`, `ltt_pladang`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(2, '2020-03-10', '2.70', 'Beloran', 'Beloran', 1, '2020-03-09 12:29:28', '2020-03-09 12:29:28'),
(3, '2020-01-14', '1.50', 'Serut', 'Dadi Subur', 1, '2020-03-15 20:25:10', '2020-03-15 20:25:10'),
(4, '2020-01-14', '2.50', 'Mutihan', 'Eko Mulyo', 1, '2020-03-15 21:42:04', '2020-03-15 21:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_psawah`
--

CREATE TABLE `ltt_psawah` (
  `id_lttpsawah` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_psawah` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ltt_psawah`
--

INSERT INTO `ltt_psawah` (`id_lttpsawah`, `tanggal_input`, `ltt_psawah`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(1, '2020-01-01', '5.00', 'Beloran', 'Beloran', 2, '2020-03-07 03:52:44', '2020-03-07 03:52:44'),
(2, '2020-03-01', '20.00', 'Serut', 'Dadi Subur', 2, '2020-03-07 03:52:44', '2020-03-07 03:52:44'),
(3, '2020-01-02', '20.00', 'Mutihan', 'Eko Mulyo', 2, '2020-03-07 03:53:54', '2020-03-07 03:53:54'),
(4, '2020-01-03', '16.00', 'Kembang', 'Kembang', 2, '2020-03-07 03:53:54', '2020-03-07 03:53:54'),
(5, '2020-01-05', '11.00', 'Kebon Dalem', 'Maju', 2, '2020-03-07 03:55:30', '2020-03-07 03:55:30'),
(6, '2020-01-07', '23.00', 'Patran', 'Manunggal Patran', 2, '2020-03-07 03:55:30', '2020-03-07 03:55:30'),
(7, '2020-01-08', '19.00', 'Morobangun', 'Morobangun', 2, '2020-03-07 03:57:59', '2020-03-07 03:57:59'),
(8, '2020-01-09', '22.00', 'Nogosari', 'Naga Sakti', 2, '2020-03-07 03:57:59', '2020-03-07 03:57:59'),
(9, '2020-01-14', '25.00', 'Gangsiran', 'Ngudi Makmur', 2, '2020-03-07 04:04:24', '2020-03-07 04:04:24'),
(10, '2020-01-11', '10.00', 'Sorogedug Lor', 'Ngudi Mekar', 2, '2020-03-07 04:04:24', '2020-03-07 04:04:24'),
(11, '2020-01-15', '15.00', 'Sonayan', 'Pesona', 2, '2020-03-07 04:05:37', '2020-03-07 04:05:37'),
(12, '2020-01-14', '8.00', 'Sembir', 'Ringin Putih', 2, '2020-03-07 04:05:37', '2020-03-07 04:05:37'),
(14, '2020-01-22', '8.00', 'Sembir', 'Ringin Putih', 2, '2020-03-06 21:06:47', '2020-03-06 21:06:47'),
(15, '2020-01-21', '20.00', 'Candisingo', 'Sedya Rukun', 2, '2020-03-06 21:07:26', '2020-03-06 21:07:26'),
(16, '2020-01-20', '14.00', 'Ketandan', 'Sedya Mulyo', 2, '2020-03-06 21:07:58', '2020-03-06 21:07:58'),
(17, '2020-01-21', '18.00', 'Tinjon', 'Sido Rukun', 2, '2020-03-06 21:08:39', '2020-03-06 21:08:39'),
(18, '2020-01-15', '5.90', 'Potrojayan', 'Tanem Tuwuh', 2, '2020-03-06 21:09:01', '2020-03-06 21:09:01'),
(19, '2020-01-23', '18.00', 'Majasem', 'Tani Rejo', 2, '2020-03-06 21:09:26', '2020-03-06 21:09:26'),
(20, '2020-01-08', '13.00', 'Kebon Dalem', 'Tunas Jaya', 2, '2020-03-06 21:09:49', '2020-03-06 21:09:49'),
(21, '2020-01-19', '15.00', 'Sorogedug Kidul', 'Sorogedug Kidul', 2, '2020-03-06 21:10:06', '2020-03-06 21:10:06'),
(22, '2020-02-04', '5.00', 'Beloran', 'Beloran', 2, '2020-03-06 21:44:30', '2020-03-06 21:44:30'),
(23, '2020-01-31', '1.20', 'Mutihan', 'Eko Mulyo', 2, '2020-03-07 07:37:26', '2020-03-07 07:37:26'),
(24, '2020-02-01', '1.20', 'Gangsiran', 'Ngudi Makmur', 2, '2020-03-07 11:18:08', '2020-03-07 11:18:08'),
(25, '2020-02-01', '1.20', 'Kebon Dalem', 'Tunas Jaya', 2, '2020-03-08 18:13:33', '2020-03-08 18:13:33'),
(26, '2020-01-14', '5.00', 'Klumprit 2', 'Tani Maju', 1, '2020-03-17 05:10:31', '2020-03-17 05:10:31'),
(27, '2020-01-30', '4.80', 'Klumprit 2', 'Tani Maju', 1, '2020-03-17 05:11:13', '2020-03-17 05:11:13'),
(28, '2020-01-15', '7.40', 'Watukangsi', 'Margi Waluyo', 1, '2020-03-17 05:11:33', '2020-03-17 05:11:33'),
(29, '2020-01-14', '4.00', 'Watukangsi', 'Sido Rahayu', 1, '2020-03-17 05:11:52', '2020-03-17 05:11:52'),
(30, '2020-01-01', '5.50', 'Losari 1', 'Ngudi Makmur', 1, '2020-03-17 05:12:15', '2020-03-17 05:12:15'),
(31, '2020-01-15', '4.90', 'Losari 1', 'Margo Dadi', 1, '2020-03-17 05:12:36', '2020-03-17 05:12:36'),
(32, '2020-01-22', '6.80', 'Losari 2', 'Rukun Santoso', 1, '2020-03-17 05:13:00', '2020-03-17 05:13:00'),
(33, '2020-01-22', '6.40', 'Losari 2', 'Ngudi Rejeki', 1, '2020-03-17 05:13:21', '2020-03-17 05:13:21'),
(34, '2020-01-15', '8.80', 'Candisari', 'Madyo Rahayu', 1, '2020-03-17 05:13:37', '2020-03-17 05:13:37'),
(35, '2020-01-16', '3.20', 'Candisari', 'Murih Raharjo', 1, '2020-03-17 05:13:57', '2020-03-17 05:13:57'),
(36, '2020-01-15', '6.20', 'Klumprit 1', 'Murih Mulyo', 1, '2020-03-17 05:14:19', '2020-03-17 05:14:19'),
(37, '2020-01-03', '6.50', 'Klumprit 1', 'Ngudi Rukun', 1, '2020-03-17 05:14:40', '2020-03-17 05:14:40'),
(38, '2020-03-18', '16.30', 'Dinginan', 'Sido Dadi', 3, '2020-03-18 11:02:54', '2020-03-18 11:02:54'),
(39, '2020-03-18', '17.80', 'Polongan', 'Manunggal', 3, '2020-03-18 11:03:32', '2020-03-18 11:03:32'),
(40, '2020-03-18', '14.20', 'Krapyak', 'Amanah', 3, '2020-03-18 11:03:56', '2020-03-18 11:03:56'),
(41, '2020-03-18', '24.90', 'Gunung gebang', 'Subur Makmur', 3, '2020-03-18 11:06:23', '2020-03-18 11:06:23'),
(42, '2020-03-18', '13.70', 'Slarongan', 'Rukun Makmur', 3, '2020-03-18 11:08:45', '2020-03-18 11:08:45'),
(43, '2020-03-18', '11.50', 'Bleber Kidul', 'Karya Muda', 3, '2020-03-18 11:09:13', '2020-03-18 11:09:13'),
(44, '2020-03-18', '17.00', 'Berjo', 'Sumber Mulyo', 3, '2020-03-18 11:11:35', '2020-03-18 11:11:35'),
(45, '2020-03-18', '17.20', 'Jurugan', 'Ngudi Rejeki', 3, '2020-03-18 11:12:00', '2020-03-18 11:12:00'),
(46, '2020-03-18', '20.00', 'Daleman', 'Triboga', 3, '2020-03-18 11:12:25', '2020-03-18 11:12:25'),
(47, '2020-03-18', '15.30', 'Ngeburan', 'Sido Makmur', 3, '2020-03-18 11:13:03', '2020-03-18 11:13:03'),
(48, '2020-03-18', '10.30', 'Klero', 'Ngudi Rejeki', 3, '2020-03-18 11:13:28', '2020-03-18 11:13:28'),
(49, '2020-03-18', '15.10', 'Bendungan', 'Margu Mulyo', 3, '2020-03-18 11:14:07', '2020-03-18 11:14:07'),
(50, '2020-03-18', '17.20', 'Kenaran', 'Sido Makmur', 3, '2020-03-18 11:14:31', '2020-03-18 11:14:31'),
(51, '2020-03-18', '16.90', 'Sawo', 'Ngudi Rejeki', 3, '2020-03-18 11:14:57', '2020-03-18 11:14:57'),
(52, '2020-03-18', '8.80', 'Umbul Sari BM', 'Mekar Sari', 3, '2020-03-18 11:15:59', '2020-03-18 11:15:59'),
(53, '2020-03-18', '9.90', 'Umbul Sari B', 'Rukun Makmur', 3, '2020-03-18 11:16:22', '2020-03-18 11:16:22'),
(54, '2020-03-18', '7.80', 'Umbul Sari A', 'Umbul Makmur', 3, '2020-03-18 11:16:50', '2020-03-18 11:16:50'),
(55, '2020-03-18', '8.65', 'Nglepen', 'Tani Makmur', 3, '2020-03-18 11:17:22', '2020-03-18 11:17:22'),
(56, '2020-03-18', '15.20', 'Sengir', 'Sari Makmur', 3, '2020-03-18 11:17:56', '2020-03-18 11:17:56'),
(57, '2020-03-18', '12.10', 'Kuncen', 'Manunggal', 3, '2020-03-18 11:18:17', '2020-03-18 11:18:17'),
(58, '2020-03-18', '9.80', 'Pereng', 'Ngudi Makmur', 3, '2020-03-18 11:18:48', '2020-03-18 11:18:48'),
(59, '2020-03-18', '15.20', 'Gamparan', 'Tani Makmur', 3, '2020-03-18 11:19:19', '2020-03-18 11:19:19'),
(60, '2020-03-18', '8.20', 'Dayakan', 'Margo Makmur', 3, '2020-03-18 11:19:38', '2020-03-18 11:19:38'),
(61, '2020-03-18', '10.00', 'Randujoko', 'Argo Makmur', 3, '2020-03-18 11:20:00', '2020-03-18 11:20:00'),
(62, '2020-01-01', '6.50', 'Kikis', 'Argo Makmur', 5, '2020-03-19 08:08:37', '2020-03-19 08:08:37'),
(63, '2020-01-01', '5.20', 'Nglengkong', 'Budidaya I', 5, '2020-03-19 08:11:14', '2020-03-19 08:11:14'),
(64, '2020-01-01', '10.50', 'Kikis', 'Lestari Rahayu', 5, '2020-03-19 08:11:44', '2020-03-19 08:11:44'),
(65, '2020-01-01', '9.80', 'Dawangsari', 'Margo Mulyo I', 5, '2020-03-19 08:12:29', '2020-03-19 08:12:29'),
(66, '2020-01-01', '7.60', 'Dawangsari', 'Margo Mulyo II', 5, '2020-03-19 08:13:00', '2020-03-19 08:13:00'),
(67, '2020-01-01', '2.20', 'Gunugnsari', 'Ngudi Makmur', 5, '2020-03-19 08:13:26', '2020-03-19 08:13:26'),
(68, '2020-01-01', '3.50', 'Gunugnsari', 'Ngudi Makmur II', 5, '2020-03-19 08:13:47', '2020-03-19 08:13:47'),
(69, '2020-01-01', '12.70', 'Gunugnsari', 'Ngudi Makmur III', 5, '2020-03-19 08:14:07', '2020-03-19 08:14:07'),
(70, '2020-01-01', '9.80', 'Gedang Bawah', 'Ngudi Rejeki I', 5, '2020-03-19 08:14:48', '2020-03-19 08:14:48'),
(71, '2020-01-01', '3.20', 'Gedang Atas', 'Ngudi Rejeki II', 5, '2020-03-19 08:15:14', '2020-03-19 08:15:14'),
(72, '2020-01-01', '2.50', 'Mlakan', 'Ngudi Rukun I', 5, '2020-03-19 08:15:44', '2020-03-19 08:15:44'),
(73, '2020-01-01', '4.30', 'Mlakan', 'Ngudi Rukun II', 5, '2020-03-19 08:16:05', '2020-03-19 08:16:05'),
(74, '2020-01-01', '8.80', 'Gunung Cilik', 'Sido Makmur II', 5, '2020-03-19 08:16:36', '2020-03-19 08:16:36'),
(75, '2020-01-01', '7.20', 'Gunung Cilik', 'Sido Rukun', 5, '2020-03-19 08:17:04', '2020-03-19 08:17:04'),
(76, '2020-01-01', '9.00', 'Sumberwatu', 'Lebdosari', 5, '2020-03-19 08:17:37', '2020-03-19 08:17:37'),
(77, '2020-01-01', '7.20', 'Parangan', 'Sedyo Mulyo', 6, '2020-03-19 08:31:36', '2020-03-19 08:31:36'),
(78, '2020-01-01', '9.90', 'Gayam', 'Sido Maju', 6, '2020-03-19 08:32:07', '2020-03-19 08:32:07'),
(79, '2020-01-01', '11.90', 'Lemahbang', 'Sido Maju', 6, '2020-03-19 08:32:44', '2020-03-19 08:32:44'),
(80, '2020-01-01', '9.80', 'Nawung', 'Sedyo Maju', 6, '2020-03-19 08:33:11', '2020-03-19 08:33:11'),
(81, '2020-01-01', '7.60', 'Jatisari', 'Ngudi Makmur', 6, '2020-03-19 08:33:36', '2020-03-19 08:33:36'),
(82, '2020-01-01', '7.90', 'Watu Gudeg', 'Ngudi Subur', 6, '2020-03-19 08:34:15', '2020-03-19 08:34:15'),
(83, '2020-01-01', '9.80', 'Dadap', 'Sido Makmur', 6, '2020-03-19 08:34:37', '2020-03-19 08:34:37'),
(84, '2020-01-01', '6.40', 'Kalinongko Kidul', 'Ngudi Makmur', 6, '2020-03-19 08:35:11', '2020-03-19 08:35:11'),
(85, '2020-01-01', '5.20', 'Kalinongko Lor', 'Sedyo Mulyo', 6, '2020-03-19 08:35:36', '2020-03-19 08:35:36'),
(86, '2020-01-01', '9.00', 'Jontro', 'Subur', 6, '2020-03-19 08:35:53', '2020-03-19 08:35:53'),
(87, '2020-01-01', '7.40', 'Jali', 'Ngudiwaras', 6, '2020-03-19 08:36:31', '2020-03-19 08:36:31'),
(88, '2020-01-01', '8.80', 'Jaligampang', 'Ngudi Makmur', 6, '2020-03-19 08:36:56', '2020-03-19 08:36:56'),
(89, '2020-01-02', '9.80', 'Jirak', 'Ngudi Mulyo', 4, '2020-03-24 04:39:15', '2020-03-24 04:39:15'),
(90, '2020-01-03', '5.40', 'Ringin Sari', 'Jonggrang', 4, '2020-03-24 04:39:52', '2020-03-24 04:39:52'),
(91, '2020-01-04', '6.20', 'Pulorejo', 'Pulerejo', 4, '2020-03-24 04:40:20', '2020-03-24 04:40:20'),
(92, '2020-03-24', '15.90', 'Jobohan', 'Sido Makmur', 4, '2020-03-24 04:41:20', '2020-03-24 04:41:20'),
(93, '2020-01-06', '24.80', 'Jamuran', 'Tani Makmur', 4, '2020-03-24 04:41:56', '2020-03-24 04:41:56'),
(94, '2020-01-07', '11.80', 'Majesam', 'Ngudi Makmur', 4, '2020-03-24 04:42:36', '2020-03-24 04:42:36'),
(95, '2020-01-10', '11.00', 'Cepik', 'Tani Maju', 4, '2020-03-24 04:43:33', '2020-03-24 04:43:33'),
(96, '2020-01-17', '10.20', 'Dawung', 'Ngudi Makmur', 4, '2020-03-24 04:45:04', '2020-03-24 04:45:04'),
(97, '2020-01-23', '5.90', 'Gatak', 'Dewi sri', 4, '2020-03-24 04:45:41', '2020-03-24 04:45:41'),
(98, '2020-03-21', '6.20', 'Candi Rejo', 'Tani Makmur', 4, '2020-03-24 04:46:10', '2020-03-24 04:46:10'),
(99, '2020-01-20', '9.80', 'Palem Sari', 'Sido Rukun', 4, '2020-03-24 04:46:53', '2020-03-24 04:46:53'),
(100, '2020-01-27', '12.40', 'Marangan', 'Tani Maju', 4, '2020-03-24 04:47:28', '2020-03-24 04:47:28');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_ujalar`
--

CREATE TABLE `ltt_ujalar` (
  `id_ujalar` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_ujalar` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_ujalar`
--

INSERT INTO `ltt_ujalar` (`id_ujalar`, `tanggal_input`, `ltt_ujalar`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(2, '2020-03-11', '2.20', 'Beloran', 'Beloran', 1, '2020-03-11 05:17:45', '2020-03-11 05:17:45'),
(3, '2020-03-12', '0.98', 'Beloran', 'Beloran', 1, '2020-03-11 05:24:03', '2020-03-11 05:24:03'),
(4, '2020-03-11', '1.20', 'Beloran', 'Beloran', 1, '2020-03-11 06:35:56', '2020-03-11 06:35:56');

-- --------------------------------------------------------

--
-- Table structure for table `ltt_ukayu`
--

CREATE TABLE `ltt_ukayu` (
  `id_ukayu` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `ltt_ukayu` decimal(8,2) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ltt_ukayu`
--

INSERT INTO `ltt_ukayu` (`id_ukayu`, `tanggal_input`, `ltt_ukayu`, `nama_dusun`, `nama_kotani`, `id`, `created_at`, `updated_at`) VALUES
(2, '2020-03-11', '1.50', 'Beloran', 'Beloran', 1, '2020-03-11 01:00:13', '2020-03-11 01:00:13');

-- --------------------------------------------------------

--
-- Table structure for table `luas_baku`
--

CREATE TABLE `luas_baku` (
  `id_lbka` int(11) NOT NULL,
  `nama_desa` varchar(20) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_baku` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `luas_baku`
--

INSERT INTO `luas_baku` (`id_lbka`, `nama_desa`, `tanggal_input`, `luas_baku`, `created_at`, `updated_at`) VALUES
(1, 'Wukirharjo', '2020-03-05', '77.00', '2020-03-05 17:01:44', '2020-03-05 10:00:22'),
(3, 'Madurejo', '2020-03-05', '355.00', '2020-03-05 10:02:27', '2020-03-05 10:02:27'),
(4, 'Sumberharjo', '2020-03-05', '372.00', '2020-03-05 10:02:45', '2020-03-05 10:02:45'),
(5, 'Bokoharjo', '2020-03-05', '147.00', '2020-03-05 10:02:57', '2020-03-05 10:02:57'),
(6, 'Sambirejo', '2020-03-05', '119.00', '2020-03-05 10:03:15', '2020-03-05 10:03:15'),
(7, 'Gayamharjo', '2020-03-05', '102.00', '2020-03-05 10:03:28', '2020-03-05 10:03:28');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tanam_bmerah`
--

CREATE TABLE `tanam_bmerah` (
  `id_bmerah` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tanam_bmerah`
--

INSERT INTO `tanam_bmerah` (`id_bmerah`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `produksi`, `created_at`, `updated_at`) VALUES
(1, 'Beloran', 'Beloran', '2020-03-25', '1.70', '1.50', '2020-03-12 08:58:26', '2020-03-12 08:58:26');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_cabai`
--

CREATE TABLE `tanam_cabai` (
  `id_cabai` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tanam_cabai`
--

INSERT INTO `tanam_cabai` (`id_cabai`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `produksi`, `created_at`, `updated_at`) VALUES
(1, 'Beloran', 'Beloran', '2020-03-27', '1.98', '2.50', '2020-03-11 20:07:50', '2020-03-11 20:07:50'),
(2, 'Serut', 'Dadi Subur', '2020-03-13', '1.50', '5.50', '2020-03-12 09:38:57', '2020-03-12 09:38:57');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_jagung`
--

CREATE TABLE `tanam_jagung` (
  `id_pjagung` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_jagung`
--

INSERT INTO `tanam_jagung` (`id_pjagung`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `created_at`, `updated_at`) VALUES
(6, 'Beloran', 'Beloran', '2020-03-31', '1.98', '2020-03-10 07:29:40', '2020-03-10 07:29:40');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_kedelai`
--

CREATE TABLE `tanam_kedelai` (
  `id_kedelai` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_kedelai`
--

INSERT INTO `tanam_kedelai` (`id_kedelai`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `created_at`, `updated_at`) VALUES
(0, 'Beloran', 'Beloran', '2020-03-26', '1.98', '2020-03-10 19:52:24', '2020-03-10 19:52:24');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_ktanah`
--

CREATE TABLE `tanam_ktanah` (
  `id_ktanah` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_ktanah`
--

INSERT INTO `tanam_ktanah` (`id_ktanah`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `produksi`, `created_at`, `updated_at`) VALUES
(2, 'Beloran', 'Beloran', '2020-02-14', '1.60', '1.30', '2020-02-14 15:35:16', '2020-02-14 15:36:13');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_pangan`
--

CREATE TABLE `tanam_pangan` (
  `id_tp` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `sawah_irigasi` decimal(8,2) NOT NULL,
  `sawah_nonirigasi` decimal(8,2) NOT NULL,
  `tegal` decimal(8,2) NOT NULL,
  `ladang` decimal(8,2) NOT NULL,
  `sem_tdk_diusahakan` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_desa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tanam_pladang`
--

CREATE TABLE `tanam_pladang` (
  `id_pladang` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_pladang`
--

INSERT INTO `tanam_pladang` (`id_pladang`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `created_at`, `updated_at`) VALUES
(1, 'Beloran', 'Beloran', '2020-03-18', '2.20', '2020-03-09 12:30:16', '2020-03-09 12:30:16'),
(2, 'Serut', 'Dadi Subur', '2020-02-26', '1.20', '2020-03-15 20:27:49', '2020-03-15 20:27:49'),
(3, 'Mutihan', 'Eko Mulyo', '2020-02-27', '1.50', '2020-03-15 21:43:08', '2020-03-15 21:43:08');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_psawah`
--

CREATE TABLE `tanam_psawah` (
  `id_psawah` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_psawah`
--

INSERT INTO `tanam_psawah` (`id_psawah`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `id`, `created_at`, `updated_at`) VALUES
(11, 'Beloran', 'Beloran', '2020-03-27', '9.80', 2, '2020-03-06 23:24:02', '2020-03-06 23:24:02'),
(12, 'Serut', 'Dadi Subur', '2020-03-26', '15.00', 2, '2020-03-06 23:25:33', '2020-03-06 23:25:33'),
(13, 'Mutihan', 'Eko Mulyo', '2020-03-31', '17.50', 2, '2020-03-06 23:36:52', '2020-03-06 23:36:52'),
(14, 'Kembang', 'Kembang', '2020-03-24', '15.00', 2, '2020-03-06 23:37:36', '2020-03-06 23:37:36'),
(15, 'Kebon Dalem', 'Maju', '2020-03-26', '9.20', 2, '2020-03-06 23:37:58', '2020-03-06 23:37:58'),
(16, 'Patran', 'Manunggal Patran', '2020-03-27', '15.00', 2, '2020-03-06 23:38:31', '2020-03-06 23:38:31'),
(17, 'Morobangun', 'Morobangun', '2020-03-20', '18.80', 2, '2020-03-06 23:38:56', '2020-03-06 23:38:56'),
(18, 'Nogosari', 'Naga Sakti', '2020-03-20', '20.00', 2, '2020-03-06 23:39:24', '2020-03-06 23:39:24'),
(19, 'Gangsiran', 'Ngudi Makmur', '2020-03-18', '24.00', 2, '2020-03-06 23:39:57', '2020-03-06 23:39:57'),
(20, 'Sorogedug Lor', 'Ngudi Mekar', '2020-03-20', '9.80', 2, '2020-03-06 23:40:37', '2020-03-06 23:40:37'),
(21, 'Sonayan', 'Pesona', '2020-03-27', '10.20', 2, '2020-03-06 23:43:26', '2020-03-06 23:43:26'),
(22, 'Sembir', 'Ringin Putih', '2020-03-25', '15.00', 2, '2020-03-06 23:44:42', '2020-03-06 23:44:42'),
(23, 'Ketandan', 'Sedya Mulyo', '2020-03-26', '14.00', 2, '2020-03-06 23:45:05', '2020-03-06 23:45:05'),
(24, 'Candisingo', 'Sedya Rukun', '2020-03-20', '18.00', 2, '2020-03-06 23:45:39', '2020-03-06 23:45:39'),
(25, 'Tinjon', 'Sido Rukun', '2020-03-19', '15.30', 2, '2020-03-06 23:46:08', '2020-03-06 23:46:08'),
(26, 'Sorogedug Kidul', 'Sorogedug Kidul', '2020-03-28', '9.80', 2, '2020-03-06 23:47:31', '2020-03-06 23:47:31'),
(27, 'Potrojayan', 'Tanem Tuwuh', '2020-03-12', '3.20', 2, '2020-03-06 23:48:04', '2020-03-06 23:48:04'),
(28, 'Majasem', 'Tani Rejo', '2020-03-28', '17.00', 2, '2020-03-07 00:14:02', '2020-03-07 00:14:02'),
(29, 'Kebon Dalem', 'Tunas Jaya', '2020-03-20', '10.00', 2, '2020-03-07 00:14:45', '2020-03-07 00:14:45'),
(30, 'Klumprit 2', 'Tani Maju', '2020-03-12', '8.00', 1, '2020-03-17 05:17:30', '2020-03-17 05:17:30'),
(31, 'Watukangsi', 'Margi Waluyo', '2020-03-06', '7.40', 1, '2020-03-17 05:17:52', '2020-03-17 05:17:52'),
(32, 'Watukangsi', 'Sido Rahayu', '2020-03-04', '3.80', 1, '2020-03-17 05:18:10', '2020-03-17 05:18:10'),
(33, 'Losari 1', 'Ngudi Makmur', '2020-03-01', '5.40', 1, '2020-03-17 05:18:45', '2020-03-17 05:18:45'),
(34, 'Losari 1', 'Margo Dadi', '2020-03-02', '4.40', 1, '2020-03-17 05:19:03', '2020-03-17 05:19:03'),
(35, 'Losari 2', 'Rukun Santoso', '2020-03-03', '6.60', 1, '2020-03-17 05:19:18', '2020-03-17 05:19:18'),
(36, 'Losari 2', 'Ngudi Rejeki', '2020-03-06', '5.20', 1, '2020-03-17 05:19:47', '2020-03-17 05:19:47'),
(37, 'Candisari', 'Madyo Rahayu', '2020-03-05', '7.20', 1, '2020-03-17 05:20:06', '2020-03-17 05:20:06'),
(38, 'Candisari', 'Murih Raharjo', '2020-03-05', '3.10', 1, '2020-03-17 05:20:22', '2020-03-17 05:20:22'),
(39, 'Klumprit 1', 'Murih Mulyo', '2020-03-06', '3.50', 1, '2020-03-17 05:20:42', '2020-03-17 05:20:42'),
(40, 'Klumprit 1', 'Ngudi Rukun', '2020-03-08', '5.90', 1, '2020-03-17 05:21:01', '2020-03-17 05:21:01'),
(41, 'Dinginan', 'Sido Dadi', '2020-03-19', '15.00', 3, '2020-03-19 02:51:08', '2020-03-19 02:51:08'),
(42, 'Polongan', 'Manunggal', '2020-03-19', '16.00', 3, '2020-03-19 02:51:34', '2020-03-19 02:51:34'),
(43, 'Krapyak', 'Amanah', '2020-03-19', '14.00', 3, '2020-03-19 02:52:00', '2020-03-19 02:52:00'),
(44, 'Gunung gebang', 'Subur Makmur', '2020-03-19', '24.80', 3, '2020-03-19 02:52:34', '2020-03-19 02:52:34'),
(45, 'Slarongan', 'Rukun Makmur', '2020-03-19', '13.60', 3, '2020-03-19 02:53:19', '2020-03-19 02:53:19'),
(46, 'Bleber Kidul', 'Karya Muda', '2020-03-19', '11.00', 3, '2020-03-19 02:53:47', '2020-03-19 02:53:47'),
(47, 'Berjo', 'Sumber Mulyo', '2020-03-19', '15.80', 3, '2020-03-19 02:54:32', '2020-03-19 02:54:32'),
(48, 'Jurugan', 'Ngudi Rejeki', '2020-03-19', '16.20', 3, '2020-03-19 02:55:33', '2020-03-19 02:55:33'),
(49, 'Daleman', 'Triboga', '2020-03-19', '19.90', 3, '2020-03-19 02:55:55', '2020-03-19 02:55:55'),
(50, 'Ngeburan', 'Sido Makmur', '2020-03-19', '15.30', 3, '2020-03-19 02:56:20', '2020-03-19 02:56:20'),
(51, 'Klero', 'Ngudi Rejeki', '2020-03-19', '10.00', 3, '2020-03-19 02:56:46', '2020-03-19 02:56:46'),
(52, 'Bendungan', 'Margu Mulyo', '2020-03-19', '15.00', 3, '2020-03-19 02:57:17', '2020-03-19 02:57:17'),
(53, 'Kenaran', 'Sido Makmur', '2020-03-19', '16.80', 3, '2020-03-19 02:57:42', '2020-03-19 02:57:42'),
(54, 'Sawo', 'Ngudi Rejeki', '2020-03-19', '15.80', 3, '2020-03-19 02:58:11', '2020-03-19 02:58:11'),
(55, 'Umbul Sari BM', 'Mekar Sari', '2020-03-19', '8.20', 3, '2020-03-19 03:59:37', '2020-03-19 03:59:37'),
(56, 'Umbul Sari B', 'Rukun Makmur', '2020-03-19', '9.20', 3, '2020-03-19 04:00:02', '2020-03-19 04:00:02'),
(57, 'Umbul Sari A', 'Umbul Makmur', '2020-03-19', '7.80', 3, '2020-03-19 04:00:34', '2020-03-19 04:00:34'),
(58, 'Nglepen', 'Tani Makmur', '2020-03-19', '8.50', 3, '2020-03-19 04:01:18', '2020-03-19 04:01:18'),
(59, 'Sengir', 'Sari Makmur', '2020-03-19', '15.10', 3, '2020-03-19 04:01:48', '2020-03-19 04:01:48'),
(60, 'Kuncen', 'Manunggal', '2020-03-19', '12.00', 3, '2020-03-19 04:02:08', '2020-03-19 04:02:08'),
(61, 'Pereng', 'Ngudi Makmur', '2020-03-19', '970.00', 0, '2020-03-19 04:04:18', '2020-03-19 04:05:28'),
(62, 'Pereng', 'Ngudi Makmur', '2020-03-19', '9.70', 3, '2020-03-19 04:06:26', '2020-03-19 04:06:26'),
(63, 'Gamparan', 'Tani Makmur', '2020-03-19', '15.60', 3, '2020-03-19 04:07:02', '2020-03-19 04:07:02'),
(64, 'Dayakan', 'Margo Makmur', '2020-03-19', '8.10', 3, '2020-03-19 04:07:38', '2020-03-19 04:07:38'),
(65, 'Randujoko', 'Argo Makmur', '2020-03-19', '5.50', 3, '2020-03-19 04:08:06', '2020-03-19 04:08:06'),
(66, 'Kikis', 'Argo Makmur', '2020-04-01', '6.20', 5, '2020-03-19 08:18:36', '2020-03-19 08:18:36'),
(67, 'Nglengkong', 'Budidaya I', '2020-04-01', '5.00', 5, '2020-03-19 08:19:01', '2020-03-19 08:19:01'),
(68, 'Kikis', 'Lestari Rahayu', '2020-04-01', '10.20', 5, '2020-03-19 08:19:21', '2020-03-19 08:19:21'),
(69, 'Dawangsari', 'Margo Mulyo I', '2020-04-01', '9.50', 5, '2020-03-19 08:19:41', '2020-03-19 08:19:41'),
(70, 'Dawangsari', 'Margo Mulyo II', '2020-04-01', '7.20', 5, '2020-03-19 08:20:02', '2020-03-19 08:20:02'),
(71, 'Gunugnsari', 'Ngudi Makmur', '2020-04-01', '2.00', 5, '2020-03-19 08:20:29', '2020-03-19 08:20:29'),
(72, 'Gunugnsari', 'Ngudi Makmur II', '2020-04-01', '3.20', 5, '2020-03-19 08:20:52', '2020-03-19 08:20:52'),
(73, 'Gunugnsari', 'Ngudi Makmur III', '2020-04-01', '12.50', 5, '2020-03-19 08:21:11', '2020-03-19 08:21:11'),
(74, 'Gedang Bawah', 'Ngudi Rejeki I', '2020-04-01', '9.50', 5, '2020-03-19 08:21:47', '2020-03-19 08:21:47'),
(75, 'Gedang Atas', 'Ngudi Rejeki II', '2020-04-01', '3.00', 5, '2020-03-19 08:22:10', '2020-03-19 08:22:10'),
(76, 'Mlakan', 'Ngudi Rukun I', '2020-04-01', '2.40', 5, '2020-03-19 08:22:38', '2020-03-19 08:22:38'),
(77, 'Mlakan', 'Ngudi Rukun II', '2020-04-01', '3.20', 5, '2020-03-19 08:22:57', '2020-03-19 08:22:57'),
(78, 'Gunung Cilik', 'Sido Makmur II', '2020-04-01', '8.70', 5, '2020-03-19 08:23:20', '2020-03-19 08:23:20'),
(79, 'Gunung Cilik', 'Sido Rukun', '2020-04-01', '6.00', 5, '2020-03-19 08:23:39', '2020-03-19 08:23:39'),
(80, 'Sumberwatu', 'Lebdosari', '2020-04-01', '8.80', 5, '2020-03-19 08:23:58', '2020-03-19 08:23:58'),
(81, 'Parangan', 'Sedyo Mulyo', '2020-04-01', '6.00', 6, '2020-03-19 08:37:30', '2020-03-19 08:37:30'),
(82, 'Gayam', 'Sido Maju', '2020-04-01', '9.80', 6, '2020-03-19 08:37:52', '2020-03-19 08:37:52'),
(83, 'Lemahbang', 'Sido Maju', '2020-04-01', '11.80', 6, '2020-03-19 08:38:14', '2020-03-19 08:38:14'),
(84, 'Nawung', 'Sedyo Maju', '2020-04-01', '7.20', 6, '2020-03-19 08:38:39', '2020-03-19 08:38:39'),
(85, 'Jatisari', 'Ngudi Makmur', '2020-04-01', '7.50', 6, '2020-03-19 08:39:37', '2020-03-19 08:39:37'),
(86, 'Watu Gudeg', 'Ngudi Subur', '2020-04-01', '7.80', 6, '2020-03-19 08:40:21', '2020-03-19 08:40:21'),
(87, 'Dadap', 'Sido Makmur', '2020-04-01', '9.60', 6, '2020-03-19 08:40:39', '2020-03-19 08:40:39'),
(88, 'Kalinongko Kidul', 'Ngudi Makmur', '2020-04-01', '6.40', 6, '2020-03-19 08:41:17', '2020-03-19 08:41:17'),
(89, 'Kalinongko Lor', 'Sedyo Mulyo', '2020-04-01', '5.10', 6, '2020-03-19 08:41:37', '2020-03-19 08:41:37'),
(90, 'Jontro', 'Subur', '2020-04-01', '3.40', 6, '2020-03-19 08:41:58', '2020-03-19 08:41:58'),
(91, 'Jali', 'Ngudiwaras', '2020-04-01', '7.00', 6, '2020-03-19 08:42:16', '2020-03-19 08:42:16'),
(92, 'Jaligampang', 'Ngudi Makmur', '2020-04-01', '8.70', 6, '2020-03-19 08:42:32', '2020-03-19 08:42:32'),
(93, 'Jirak', 'Ngudi Mulyo', '2020-03-01', '9.70', 4, '2020-03-24 04:26:03', '2020-03-24 04:26:03'),
(94, 'Ringin Sari', 'Jonggrang', '2020-03-02', '5.00', 4, '2020-03-24 04:26:44', '2020-03-24 04:26:44'),
(95, 'Pulorejo', 'Pulerejo', '2020-03-03', '6.00', 4, '2020-03-24 04:27:23', '2020-03-24 04:27:23'),
(96, 'Jobohan', 'Sido Makmur', '2020-03-04', '15.00', 4, '2020-03-24 04:28:24', '2020-03-24 04:28:24'),
(97, 'Jamuran', 'Tani Makmur', '2020-03-05', '24.00', 4, '2020-03-24 04:29:15', '2020-03-24 04:29:15'),
(98, 'Majasem', 'Ngudi Makmur', '2020-03-06', '108.00', 0, '2020-03-24 04:29:56', '2020-03-24 04:30:59'),
(99, 'Majesam', 'Ngudi Makmur', '2020-03-06', '10.80', 4, '2020-03-24 04:32:29', '2020-03-24 04:32:29'),
(100, 'Cepik', 'Tani Maju', '2020-03-07', '9.20', 4, '2020-03-24 04:33:06', '2020-03-24 04:33:06'),
(101, 'Beloran', 'Dadi Subur', '2020-03-24', '920.00', 0, '2020-03-24 04:34:00', '2020-03-24 04:34:33'),
(102, 'Dawung', 'Ngudi Makmur', '2020-03-24', '10.00', 4, '2020-03-24 04:35:24', '2020-03-24 04:35:24'),
(103, 'Gatak', 'Dewi sri', '2020-03-10', '5.40', 4, '2020-03-24 04:36:06', '2020-03-24 04:36:06'),
(104, 'Candi Rejo', 'Tani Makmur', '2020-03-12', '6.10', 4, '2020-03-24 04:36:33', '2020-03-24 04:36:33'),
(105, 'Palem Sari', 'Sido Rukun', '2020-03-18', '9.70', 4, '2020-03-24 04:37:07', '2020-03-24 04:37:07'),
(106, 'Marangan', 'Tani Maju', '2020-03-19', '12.10', 4, '2020-03-24 04:37:33', '2020-03-24 04:37:33');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_ujalar`
--

CREATE TABLE `tanam_ujalar` (
  `id_ujalar` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_ujalar`
--

INSERT INTO `tanam_ujalar` (`id_ujalar`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `produksi`, `created_at`, `updated_at`) VALUES
(2, 'Beloran', 'Beloran', '2020-03-27', '2.10', '1.90', '2020-03-11 05:18:09', '2020-03-11 05:18:09'),
(3, 'Beloran', 'Beloran', '2020-03-27', '1.50', '1.40', '2020-03-11 06:39:14', '2020-03-11 06:39:14');

-- --------------------------------------------------------

--
-- Table structure for table `tanam_ukayu`
--

CREATE TABLE `tanam_ukayu` (
  `id_ukayu` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `tanggal_input` date NOT NULL,
  `luas_panen` decimal(8,2) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanam_ukayu`
--

INSERT INTO `tanam_ukayu` (`id_ukayu`, `nama_dusun`, `nama_kotani`, `tanggal_input`, `luas_panen`, `produksi`, `created_at`, `updated_at`) VALUES
(2, 'Beloran', 'Beloran', '2020-03-26', '1.80', '1.30', '2020-03-11 00:27:12', '2020-03-11 00:27:12');

-- --------------------------------------------------------

--
-- Table structure for table `ubinan`
--

CREATE TABLE `ubinan` (
  `id_ubinan` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `periode` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ubinan`
--

INSERT INTO `ubinan` (`id_ubinan`, `tanggal_input`, `periode`, `nama_dusun`, `nama_kotani`, `produksi`, `id`, `created_at`, `updated_at`) VALUES
(1, '2020-03-07', 1, 'Beloran', 'Beloran', '5.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:52:25'),
(2, '2020-03-08', 1, 'Serut', 'Dadi Subur', '4.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:52:25'),
(3, '2020-03-09', 1, 'Mutihan', 'Eko Mulyo', '6.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:54:10'),
(4, '2020-03-11', 1, 'Kembang', 'Kembang', '3.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:54:10'),
(5, '2020-03-11', 1, 'Kebon Dalem', 'Maju', '7.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:55:02'),
(6, '2020-03-12', 1, 'Patran', 'Manunggal Patran', '8.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:55:02'),
(7, '2020-03-13', 1, 'Morobangun', 'Morobangun', '2.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:56:04'),
(8, '2020-03-24', 1, 'Nogosari', 'Naga Sakti', '5.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:56:04'),
(9, '2020-03-23', 1, 'Gangsiran', 'Ngudi Makmur', '6.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:57:14'),
(10, '2020-03-22', 1, 'Sorogedung Lor', 'Ngudi Mekar', '5.00', 2, '2020-03-18 07:37:11', '2020-03-07 05:57:14'),
(11, '2020-03-12', 1, 'Sonayan', 'Pesona', '4.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:06:15'),
(12, '2020-03-20', 1, 'Sembir', 'Ringin Putih', '6.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:07:45'),
(13, '2020-03-19', 1, 'Candisingo', 'Sedya Rukun', '7.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:08:46'),
(14, '2020-03-07', 1, 'Ketandan', 'Sedya Mulyo', '8.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:09:10'),
(15, '2020-03-19', 1, 'Tinjon', 'Sido Rukun', '4.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:09:39'),
(16, '2020-03-19', 1, 'Potrojayan', 'Tanem Tuwuh', '6.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:10:03'),
(17, '2020-03-19', 1, 'Majasem', 'Tani Rejo', '4.00', 2, '2020-03-18 07:37:11', '2020-03-06 23:10:25'),
(18, '2020-03-24', 1, 'Kebon Dalem', 'Tunas Jaya', '5.00', 2, '2020-03-18 07:37:12', '2020-03-06 23:10:52'),
(19, '2020-03-12', 1, 'Sorogedug Kidul', 'Sorogedug Kidul', '6.00', 2, '2020-03-18 07:37:12', '2020-03-06 23:11:11'),
(20, '2020-03-25', 1, 'Klumprit 2', 'Tani Maju', '4.00', 1, '2020-03-18 07:37:12', '2020-03-17 05:22:00'),
(21, '2020-03-26', 1, 'Watukangsi', 'Margi Waluyo', '3.00', 1, '2020-03-18 07:37:12', '2020-03-17 05:24:20'),
(22, '2020-03-28', 1, 'Watukangsi', 'Sido Rahayu', '2.00', 1, '2020-03-18 07:37:12', '2020-03-17 05:25:15'),
(23, '2020-03-28', 1, 'Losari 1', 'Ngudi Makmur', '5.00', 1, '2020-03-18 07:37:12', '2020-03-17 05:26:05'),
(24, '2020-03-28', 1, 'Losari 1', 'Margo Dadi', '9.00', 1, '2020-03-18 07:37:12', '2020-03-17 05:26:45'),
(25, '2020-03-27', 1, 'Losari 2', 'Rukun Santoso', '7.00', 1, '0000-00-00 00:00:00', '2020-03-17 05:27:27'),
(26, '2020-03-29', 1, 'Losari 2', 'Ngudi Rejeki', '6.00', 1, '2020-03-18 07:38:04', '2020-03-17 05:28:01'),
(27, '2020-03-28', 1, 'Candisari', 'Madyo Rahayu', '5.00', 1, '2020-03-18 07:38:04', '2020-03-17 05:28:38'),
(28, '2020-03-28', 1, 'Candisari', 'Murih Raharjo', '4.00', 1, '2020-03-18 07:38:04', '2020-03-17 05:29:14'),
(29, '2020-03-28', 1, 'Klumprit 1', 'Murih Mulyo', '2.00', 1, '2020-03-18 07:38:04', '2020-03-17 05:29:49'),
(30, '2020-03-27', 1, 'Klumprit 1', 'Ngudi Rukun', '3.00', 1, '2020-03-18 07:38:04', '2020-03-17 05:30:16'),
(31, '2020-03-19', 1, 'Dinginan', 'Sido Dadi', '10.00', 3, '2020-03-19 04:16:39', '2020-03-19 04:16:39'),
(32, '2020-03-19', 1, 'Polongan', 'Manunggal', '11.00', 3, '2020-03-19 04:17:08', '2020-03-19 04:17:08'),
(33, '2020-03-19', 1, 'Krapyak', 'Amanah', '12.00', 3, '2020-03-19 04:17:42', '2020-03-19 04:17:42'),
(34, '2020-03-19', 1, 'Gunung gebang', 'Subur Makmur', '9.00', 3, '2020-03-19 04:18:04', '2020-03-19 04:18:04'),
(35, '2020-03-19', 1, 'Slarongan', 'Rukun Makmur', '8.00', 3, '2020-03-19 04:19:05', '2020-03-19 04:19:05'),
(36, '2020-03-19', 1, 'Bleber Kidul', 'Karya Muda', '7.00', 3, '2020-03-19 04:19:36', '2020-03-19 04:19:36'),
(37, '2020-03-19', 1, 'Berjo', 'Sumber Mulyo', '10.00', 3, '2020-03-19 04:20:50', '2020-03-19 04:20:50'),
(38, '2020-03-19', 1, 'Jurugan', 'Ngudi Rejeki', '12.00', 3, '2020-03-19 04:21:57', '2020-03-19 04:21:57'),
(39, '2020-03-19', 1, 'Daleman', 'Triboga', '11.00', 3, '2020-03-19 04:22:19', '2020-03-19 04:22:19'),
(40, '2020-03-19', 1, 'Ngeburan', 'Sido Makmur', '13.00', 3, '2020-03-19 04:23:05', '2020-03-19 04:23:05'),
(41, '2020-03-19', 1, 'Klero', 'Ngudi Rejeki', '15.00', 3, '2020-03-19 04:23:31', '2020-03-19 04:23:31'),
(42, '2020-03-19', 1, 'Bendungan', 'Margu Mulyo', '9.00', 3, '2020-03-19 04:24:03', '2020-03-19 04:24:03'),
(43, '2020-03-19', 1, 'Kenaran', 'Sido Makmur', '2.00', 3, '2020-03-19 04:24:38', '2020-03-19 04:24:38'),
(44, '2020-03-19', 1, 'Sawo', 'Ngudi Rejeki', '4.00', 3, '2020-03-19 04:25:07', '2020-03-19 04:25:07'),
(45, '2020-03-19', 1, 'Umbul Sari BM', 'Mekar Sari', '8.00', 3, '2020-03-19 04:25:44', '2020-03-19 04:25:44'),
(46, '2020-03-19', 1, 'Umbul Sari B', 'Rukun Makmur', '9.00', 3, '2020-03-19 04:26:13', '2020-03-19 04:26:13'),
(47, '2020-03-19', 1, 'Umbul Sari A', 'Umbul Makmur', '7.00', 3, '2020-03-19 04:26:35', '2020-03-19 04:26:35'),
(48, '2020-03-19', 1, 'Nglepen', 'Tani Makmur', '6.00', 3, '2020-03-19 04:29:49', '2020-03-19 04:29:49'),
(49, '2020-03-19', 1, 'Sengir', 'Sari Makmur', '10.00', 3, '2020-03-19 04:30:22', '2020-03-19 04:30:22'),
(50, '2020-03-19', 1, 'Kuncen', 'Manunggal', '11.00', 3, '2020-03-19 04:30:41', '2020-03-19 04:30:41'),
(51, '2020-03-19', 1, 'Pereng', 'Ngudi Makmur', '12.00', 3, '2020-03-19 04:31:11', '2020-03-19 04:31:11'),
(52, '2020-03-19', 1, 'Gamparan', 'Tani Makmur', '12.00', 3, '2020-03-19 04:31:54', '2020-03-19 04:31:54'),
(53, '2020-03-19', 1, 'Dayakan', 'Margo Makmur', '6.00', 3, '2020-03-19 04:32:16', '2020-03-19 04:32:16'),
(54, '2020-03-19', 1, 'Dayakan', 'Margo Makmur', '5.00', 3, '2020-03-19 04:32:41', '2020-03-19 04:32:41'),
(55, '2020-03-19', 1, 'Randujoko', 'Argo Makmur', '2.00', 3, '2020-03-19 04:33:00', '2020-03-19 04:33:00'),
(56, '2020-03-01', 1, 'Kikis', 'Argo Makmur', '4.00', 5, '2020-03-19 08:24:36', '2020-03-19 08:24:36'),
(57, '2020-03-01', 1, 'Nglengkong', 'Budidaya I', '2.00', 5, '2020-03-19 08:25:01', '2020-03-19 08:25:01'),
(58, '2020-03-01', 1, 'Kikis', 'Lestari Rahayu', '3.00', 5, '2020-03-19 08:25:20', '2020-03-19 08:25:20'),
(59, '2020-03-01', 1, 'Dawangsari', 'Margo Mulyo I', '6.00', 5, '2020-03-19 08:25:40', '2020-03-19 08:25:40'),
(60, '2020-03-01', 1, 'Dawangsari', 'Margo Mulyo II', '5.00', 5, '2020-03-19 08:25:56', '2020-03-19 08:25:56'),
(61, '2020-03-01', 1, 'Gunugnsari', 'Ngudi Makmur', '4.00', 5, '2020-03-19 08:26:15', '2020-03-19 08:26:15'),
(62, '2020-03-01', 1, 'Gunugnsari', 'Ngudi Makmur II', '3.00', 5, '2020-03-19 08:26:37', '2020-03-19 08:26:37'),
(63, '2020-03-01', 1, 'Gunugnsari', 'Ngudi Makmur III', '2.00', 5, '2020-03-19 08:26:56', '2020-03-19 08:26:56'),
(64, '2020-03-01', 1, 'Gedang Bawah', 'Ngudi Rejeki I', '6.00', 5, '2020-03-19 08:27:22', '2020-03-19 08:27:22'),
(65, '2020-03-01', 1, 'Gedang Atas', 'Ngudi Rejeki II', '7.00', 5, '2020-03-19 08:27:39', '2020-03-19 08:27:39'),
(66, '2020-03-01', 1, 'Mlakan', 'Ngudi Rukun I', '2.00', 5, '2020-03-19 08:28:00', '2020-03-19 08:28:00'),
(67, '2020-03-01', 1, 'Mlakan', 'Ngudi Rukun II', '4.00', 5, '2020-03-19 08:28:19', '2020-03-19 08:28:19'),
(68, '2020-03-01', 1, 'Gunung Cilik', 'Sido Makmur II', '3.00', 5, '2020-03-19 08:28:37', '2020-03-19 08:28:37'),
(69, '2020-03-01', 1, 'Gunung Cilik', 'Sido Rukun', '5.00', 5, '2020-03-19 08:28:53', '2020-03-19 08:28:53'),
(70, '2020-03-01', 1, 'Sumberwatu', 'Lebdosari', '6.00', 5, '2020-03-19 08:29:07', '2020-03-19 08:29:07'),
(71, '2020-03-01', 1, 'Parangan', 'Sedyo Mulyo', '4.00', 6, '2020-03-19 08:50:20', '2020-03-19 08:50:20'),
(72, '2020-03-01', 1, 'Gayam', 'Sido Maju', '3.00', 6, '2020-03-19 08:50:50', '2020-03-19 08:50:50'),
(73, '2020-03-01', 1, 'Lemahbang', 'Sido Maju', '5.00', 6, '2020-03-19 08:51:12', '2020-03-19 08:51:12'),
(74, '2020-03-01', 1, 'Nawung', 'Sedyo Maju', '6.00', 6, '2020-03-19 08:51:46', '2020-03-19 08:51:46'),
(75, '2020-03-01', 1, 'Jatisari', 'Ngudi Makmur', '7.00', 6, '2020-03-19 08:52:29', '2020-03-19 08:52:29'),
(76, '2020-03-01', 1, 'Watu Gudeg', 'Ngudi Subur', '8.00', 6, '2020-03-19 08:52:59', '2020-03-19 08:52:59'),
(77, '2020-03-01', 1, 'Dadap', 'Sido Makmur', '4.00', 6, '2020-03-19 08:53:18', '2020-03-19 08:53:18'),
(78, '2020-03-01', 1, 'Kalinongko Kidul', 'Ngudi Makmur', '3.00', 6, '2020-03-19 08:53:46', '2020-03-19 08:53:46'),
(79, '2020-03-01', 1, 'Kalinongko Lor', 'Sedyo Mulyo', '6.00', 6, '2020-03-19 08:54:20', '2020-03-19 08:54:20'),
(80, '2020-03-01', 1, 'Jontro', 'Subur', '2.00', 6, '2020-03-19 08:54:37', '2020-03-19 08:54:37'),
(81, '2020-03-01', 1, 'Jali', 'Ngudiwaras', '4.00', 6, '2020-03-19 08:55:14', '2020-03-19 08:55:14'),
(82, '2020-03-01', 1, 'Jaligampang', 'Ngudi Makmur', '6.00', 6, '2020-03-19 08:55:26', '2020-03-19 08:55:26'),
(83, '2020-04-01', 1, 'Ringin Sari', 'Jonggrang', '4.00', 4, '2020-03-24 04:48:02', '2020-03-24 04:48:02'),
(84, '2020-04-02', 1, 'Pulorejo', 'Pulerejo', '3.00', 4, '2020-03-24 04:48:35', '2020-03-24 04:48:35'),
(85, '2020-04-03', 1, 'Jobohan', 'Sido Makmur', '2.00', 4, '2020-03-24 04:49:01', '2020-03-24 04:49:01'),
(86, '2020-04-05', 1, 'Jobohan', 'Sido Makmur', '5.00', 4, '2020-03-24 04:49:38', '2020-03-24 04:49:38'),
(87, '2020-04-07', 1, 'Jamuran', 'Tani Makmur', '4.00', 4, '2020-03-24 04:50:04', '2020-03-24 04:50:04'),
(88, '2020-04-08', 1, 'Majesam', 'Ngudi Makmur', '4.00', 4, '2020-03-24 04:50:30', '2020-03-24 04:50:30'),
(89, '2020-04-10', 1, 'Cepik', 'Tani Maju', '6.00', 4, '2020-03-24 04:51:00', '2020-03-24 04:51:00'),
(90, '2020-04-11', 1, 'Dawung', 'Ngudi Makmur', '3.00', 4, '2020-03-24 04:51:23', '2020-03-24 04:51:23'),
(91, '2020-04-12', 1, 'Gatak', 'Dewi sri', '7.00', 4, '2020-03-24 04:51:52', '2020-03-24 04:51:52'),
(92, '2020-04-13', 1, 'Candi Rejo', 'Tani Makmur', '8.00', 4, '2020-03-24 04:52:37', '2020-03-24 04:52:37'),
(93, '2020-04-15', 1, 'Palem Sari', 'Sido Rukun', '2.00', 4, '2020-03-24 04:53:08', '2020-03-24 04:53:08'),
(94, '2020-04-24', 1, 'Marangan', 'Tani Maju', '8.00', 4, '2020-03-24 04:53:35', '2020-03-24 04:53:35');

-- --------------------------------------------------------

--
-- Table structure for table `ubinan_jagung`
--

CREATE TABLE `ubinan_jagung` (
  `id_ubinan` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `periode` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `u1` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ubinan_jagung`
--

INSERT INTO `ubinan_jagung` (`id_ubinan`, `tanggal_input`, `periode`, `nama_dusun`, `nama_kotani`, `u1`, `created_at`, `updated_at`) VALUES
(2, '2020-03-26', 1, 'Beloran', 'Beloran', '6.25', '2020-03-10 07:28:59', '2020-03-10 07:28:59'),
(3, '2020-03-10', 1, 'Candisingo', 'Dadi Subur', '6.25', '2020-03-10 18:48:07', '2020-03-10 18:48:07');

-- --------------------------------------------------------

--
-- Table structure for table `ubinan_kedelai`
--

CREATE TABLE `ubinan_kedelai` (
  `id_ubinan` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `periode` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `u1` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ubinan_kedelai`
--

INSERT INTO `ubinan_kedelai` (`id_ubinan`, `tanggal_input`, `periode`, `nama_dusun`, `nama_kotani`, `u1`, `created_at`, `updated_at`) VALUES
(2, '2020-03-27', 1, 'Beloran', 'Beloran', '6.25', '2020-03-10 19:50:28', '2020-03-10 19:50:28');

-- --------------------------------------------------------

--
-- Table structure for table `ubinan_pladang`
--

CREATE TABLE `ubinan_pladang` (
  `id_ubinan` int(11) NOT NULL,
  `tanggal_input` date NOT NULL,
  `periode` int(11) NOT NULL,
  `nama_dusun` varchar(50) NOT NULL,
  `nama_kotani` varchar(50) NOT NULL,
  `produksi` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ubinan_pladang`
--

INSERT INTO `ubinan_pladang` (`id_ubinan`, `tanggal_input`, `periode`, `nama_dusun`, `nama_kotani`, `produksi`, `created_at`, `updated_at`) VALUES
(2, '2020-03-31', 1, 'Beloran', 'Beloran', '2.00', '2020-03-09 12:29:52', '2020-03-09 12:29:52'),
(3, '2020-02-12', 1, 'Serut', 'Dadi Subur', '3.00', '2020-03-15 20:26:00', '2020-03-15 20:26:00'),
(4, '2020-02-19', 1, 'Mutihan', 'Eko Mulyo', '4.00', '2020-03-15 21:42:26', '2020-03-15 21:42:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telp` varchar(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `id_desa` int(11) NOT NULL,
  `jabatan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isAdmin` enum('1','0','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `no_telp`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `id_desa`, `jabatan`, `isAdmin`, `role`) VALUES
(1, 'Wukirharjo', 'wukirharjo@gmail.com', '085600921179', NULL, '$2y$10$l3nCMUTN8oVdlRtm0uRuwefsIYuW6pNyqSwuGAY/Yadh9ieqLvmOy', NULL, '2020-03-17 22:32:17', '2020-03-17 22:32:17', 1, 'Admin', '1', ''),
(2, 'Madurejo', 'madurejo@gmail.com', '08978092368', NULL, '$2y$10$XrdYqrIQk0K5BrRYlfefeuoviah2bsx4dZj81U3siUzjAiDDJM6Ua', NULL, '2020-03-17 22:33:35', '2020-03-17 22:33:35', 2, 'Admin', '1', ''),
(3, 'Sumberharjo', 'sumberharjo@gmail.com', '085647490570', NULL, '$2y$10$AqW8ilXjSHf3bTJ5GOGEu.OyDKEt1Wypn92l2ms5f45tNNbxdGe5m', NULL, '2020-03-17 22:34:38', '2020-03-17 22:34:38', 3, 'Admin', '1', ''),
(4, 'Bokoharjo', 'bokoharjo@gmail.com', '081226934509', NULL, '$2y$10$kwTOBPomP1q74qV9ZeLNw.JLYiJGnaYURTyK7/zkpv7V/phwGf9kW', NULL, '2020-03-17 22:35:12', '2020-03-17 22:35:12', 4, 'Admin', '1', ''),
(5, 'Sambirejo', 'sambirejo@gmail.com', '081567655731', NULL, '$2y$10$CbiGfES5wPva.AOpQM83HeqHRbS73oCxbw8mShAtKiQX2cg7cJg6i', NULL, '2020-03-17 22:35:43', '2020-03-17 22:35:43', 5, 'Admin', '1', ''),
(6, 'Gayamharjo', 'gayamharjo@gmail.com', '087838649107', NULL, '$2y$10$bZk5AkWQ1slaQ/qsDKmlzu07w58hsjesAmEzlID4TnVT4ngjYrszK', NULL, '2020-03-17 22:36:19', '2020-03-17 22:36:19', 6, 'Admin', '1', ''),
(10, 'Laeli', 'laeli@gmail.com', '089647095502', NULL, '$2y$10$ua8BTwWre39LLLxt39twJOsiop/Ns07D5I/Cz8cEbNXcfXci2027.', NULL, '2020-02-26 21:50:59', '2020-02-26 21:50:59', 2, 'user', '1', 'user'),
(11, 'Oka', 'oka@gmail.com', '089654789654', NULL, '$2y$10$mmU4GW0rkZX529vyxRMPUerVsbs8NjSftmjb8u1Jo3xxSC2VGDPYu', NULL, '2020-02-27 00:25:00', '2020-02-27 00:25:00', 1, 'User', '1', 'user'),
(12, 'Hapis', 'hapis@gmail.com', '089754896547', NULL, '$2y$10$r6l3zdV72Dzz795dmtEQSuKIAuJzgeYEfpPcBvFMkhXnxm9VB86Ry', NULL, '2020-02-27 00:39:04', '2020-02-27 00:39:04', 3, 'user', '1', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `desa`
--
ALTER TABLE `desa`
  ADD PRIMARY KEY (`id_desa`);

--
-- Indexes for table `dusun`
--
ALTER TABLE `dusun`
  ADD PRIMARY KEY (`nama_dusun`);

--
-- Indexes for table `frekuensi_tanam`
--
ALTER TABLE `frekuensi_tanam`
  ADD PRIMARY KEY (`id_frekuensi`);

--
-- Indexes for table `hama`
--
ALTER TABLE `hama`
  ADD PRIMARY KEY (`id_hama`);

--
-- Indexes for table `kecamatan`
--
ALTER TABLE `kecamatan`
  ADD PRIMARY KEY (`id_kecamatan`);

--
-- Indexes for table `kotani`
--
ALTER TABLE `kotani`
  ADD PRIMARY KEY (`id_kotani`) USING BTREE,
  ADD KEY `id` (`id`);

--
-- Indexes for table `ltt_bmerah`
--
ALTER TABLE `ltt_bmerah`
  ADD PRIMARY KEY (`id_bmerah`);

--
-- Indexes for table `ltt_cabai`
--
ALTER TABLE `ltt_cabai`
  ADD PRIMARY KEY (`id_cabai`);

--
-- Indexes for table `ltt_jagung`
--
ALTER TABLE `ltt_jagung`
  ADD PRIMARY KEY (`id_jagung`);

--
-- Indexes for table `ltt_kedelai`
--
ALTER TABLE `ltt_kedelai`
  ADD PRIMARY KEY (`id_kedelai`);

--
-- Indexes for table `ltt_ktanah`
--
ALTER TABLE `ltt_ktanah`
  ADD PRIMARY KEY (`id_ktanah`);

--
-- Indexes for table `ltt_pladang`
--
ALTER TABLE `ltt_pladang`
  ADD PRIMARY KEY (`id_lttpladang`);

--
-- Indexes for table `ltt_psawah`
--
ALTER TABLE `ltt_psawah`
  ADD PRIMARY KEY (`id_lttpsawah`);

--
-- Indexes for table `ltt_ujalar`
--
ALTER TABLE `ltt_ujalar`
  ADD PRIMARY KEY (`id_ujalar`);

--
-- Indexes for table `ltt_ukayu`
--
ALTER TABLE `ltt_ukayu`
  ADD PRIMARY KEY (`id_ukayu`);

--
-- Indexes for table `luas_baku`
--
ALTER TABLE `luas_baku`
  ADD PRIMARY KEY (`id_lbka`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tanam_bmerah`
--
ALTER TABLE `tanam_bmerah`
  ADD PRIMARY KEY (`id_bmerah`);

--
-- Indexes for table `tanam_cabai`
--
ALTER TABLE `tanam_cabai`
  ADD PRIMARY KEY (`id_cabai`);

--
-- Indexes for table `tanam_jagung`
--
ALTER TABLE `tanam_jagung`
  ADD PRIMARY KEY (`id_pjagung`);

--
-- Indexes for table `tanam_kedelai`
--
ALTER TABLE `tanam_kedelai`
  ADD PRIMARY KEY (`id_kedelai`);

--
-- Indexes for table `tanam_ktanah`
--
ALTER TABLE `tanam_ktanah`
  ADD PRIMARY KEY (`id_ktanah`);

--
-- Indexes for table `tanam_pangan`
--
ALTER TABLE `tanam_pangan`
  ADD PRIMARY KEY (`id_tp`),
  ADD KEY `id_user` (`id_desa`);

--
-- Indexes for table `tanam_pladang`
--
ALTER TABLE `tanam_pladang`
  ADD PRIMARY KEY (`id_pladang`);

--
-- Indexes for table `tanam_psawah`
--
ALTER TABLE `tanam_psawah`
  ADD PRIMARY KEY (`id_psawah`);

--
-- Indexes for table `tanam_ujalar`
--
ALTER TABLE `tanam_ujalar`
  ADD PRIMARY KEY (`id_ujalar`);

--
-- Indexes for table `tanam_ukayu`
--
ALTER TABLE `tanam_ukayu`
  ADD PRIMARY KEY (`id_ukayu`);

--
-- Indexes for table `ubinan`
--
ALTER TABLE `ubinan`
  ADD PRIMARY KEY (`id_ubinan`),
  ADD KEY `nama_dusun` (`nama_kotani`);

--
-- Indexes for table `ubinan_jagung`
--
ALTER TABLE `ubinan_jagung`
  ADD PRIMARY KEY (`id_ubinan`);

--
-- Indexes for table `ubinan_kedelai`
--
ALTER TABLE `ubinan_kedelai`
  ADD PRIMARY KEY (`id_ubinan`);

--
-- Indexes for table `ubinan_pladang`
--
ALTER TABLE `ubinan_pladang`
  ADD PRIMARY KEY (`id_ubinan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_desa` (`id_desa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `desa`
--
ALTER TABLE `desa`
  MODIFY `id_desa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `frekuensi_tanam`
--
ALTER TABLE `frekuensi_tanam`
  MODIFY `id_frekuensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hama`
--
ALTER TABLE `hama`
  MODIFY `id_hama` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kecamatan`
--
ALTER TABLE `kecamatan`
  MODIFY `id_kecamatan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kotani`
--
ALTER TABLE `kotani`
  MODIFY `id_kotani` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `ltt_bmerah`
--
ALTER TABLE `ltt_bmerah`
  MODIFY `id_bmerah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ltt_cabai`
--
ALTER TABLE `ltt_cabai`
  MODIFY `id_cabai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ltt_jagung`
--
ALTER TABLE `ltt_jagung`
  MODIFY `id_jagung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ltt_kedelai`
--
ALTER TABLE `ltt_kedelai`
  MODIFY `id_kedelai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ltt_ktanah`
--
ALTER TABLE `ltt_ktanah`
  MODIFY `id_ktanah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ltt_pladang`
--
ALTER TABLE `ltt_pladang`
  MODIFY `id_lttpladang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ltt_psawah`
--
ALTER TABLE `ltt_psawah`
  MODIFY `id_lttpsawah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `ltt_ujalar`
--
ALTER TABLE `ltt_ujalar`
  MODIFY `id_ujalar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ltt_ukayu`
--
ALTER TABLE `ltt_ukayu`
  MODIFY `id_ukayu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `luas_baku`
--
ALTER TABLE `luas_baku`
  MODIFY `id_lbka` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tanam_bmerah`
--
ALTER TABLE `tanam_bmerah`
  MODIFY `id_bmerah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tanam_cabai`
--
ALTER TABLE `tanam_cabai`
  MODIFY `id_cabai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tanam_jagung`
--
ALTER TABLE `tanam_jagung`
  MODIFY `id_pjagung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tanam_pladang`
--
ALTER TABLE `tanam_pladang`
  MODIFY `id_pladang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tanam_psawah`
--
ALTER TABLE `tanam_psawah`
  MODIFY `id_psawah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `tanam_ujalar`
--
ALTER TABLE `tanam_ujalar`
  MODIFY `id_ujalar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tanam_ukayu`
--
ALTER TABLE `tanam_ukayu`
  MODIFY `id_ukayu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ubinan`
--
ALTER TABLE `ubinan`
  MODIFY `id_ubinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `ubinan_jagung`
--
ALTER TABLE `ubinan_jagung`
  MODIFY `id_ubinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ubinan_kedelai`
--
ALTER TABLE `ubinan_kedelai`
  MODIFY `id_ubinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ubinan_pladang`
--
ALTER TABLE `ubinan_pladang`
  MODIFY `id_ubinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_desa`) REFERENCES `desa` (`id_desa`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
